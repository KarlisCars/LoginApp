//
//  ViewController.swift
//  LoginAPP
//
//  Created by Arkadijs Makarenko on 05/11/2019.
//  Copyright © 2019 Arkadijs Makarenko. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var userNameTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    
    private let userName = "am"
    private let password = "am"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    // MARK: - Navigation

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        guard segue.identifier == "login" else {return}
        
        let welcomeVC = segue.destination as! WelcomeViewController
        
        // Pass the selected object to the new view controller.
        welcomeVC.userName = userNameTextField.text
        view.endEditing(true)
    }
    
    @IBAction func unwindSegue(segue: UIStoryboardSegue){
        
    }
    
    @IBAction func logingTapped() {
        guard userNameTextField.text == userName, passwordTextField.text == password else {
            warningPopUp(withTitle: "Invalid login or password", withMessage: "Please enter correct login/password")
            return
        }
        performSegue(withIdentifier: "login", sender: nil)
    }
    
    @IBAction func forgotPasswordTapped() {
        warningPopUp(withTitle: "Oops!", withMessage: "Your name is: \(password)")
    }
    
    @IBAction func forgotUsernameTapped() {
         warningPopUp(withTitle: "Oops!", withMessage: "Your name is: \(userName)")
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
           super.touchesBegan(touches, with: event)
           view.endEditing(true)
       }
    
}//end VC

// MARK: - Alert Controller
extension UIViewController{
    func warningPopUp(withTitle title : String?, withMessage message : String?){
        DispatchQueue.main.async {
            
            let popUP = UIAlertController(title: title, message: message, preferredStyle: .alert)
            let okButton = UIAlertAction(title: "OK", style: .cancel, handler: nil)
            popUP.addAction(okButton)
            self.present(popUP, animated: true, completion: nil)
        }
    }
}
// MARK: Text Field Delegate
extension ViewController: UITextFieldDelegate {

    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if textField == userNameTextField {
            textField.resignFirstResponder()
            passwordTextField.becomeFirstResponder()
        } else {
            logingTapped()
        }
        return true
    }
}
